Scratched Letters Font

The Scratched Letters font is a display font. It is based on the Impact font but I scribbled on the letters with a white brush on Microsoft Paint. It comes with A-Z letters only because this font is a large file. This font is in the public domain; please read the terms of use at http://jlhfonts.blogspot.com/